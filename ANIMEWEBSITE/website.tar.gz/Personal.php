<html>
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Personal</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" type="text/css" media="screen" href="personal.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/main.css" />
    <link rel="stylesheet" type="text/css" media="screen" href="css/usuario.css" />
    <script src="personal.js"></script>
</head>
<body>


<?php
    session_start();
    include("includes/header.php"); 
    include("includes/content_usuario.php");
?>


</body>
</html>