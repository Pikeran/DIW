<div id="contenido-central">
    <div class="galeria-img"></div>
 </div> 