     <div id = "contenedor-principal">

        <div class="perfil">
            <div class="foto">
                <div id = "imagen-perfil">
                    
                </div>
            </div>
            <div class="info">
                 <table style="width:100%">
                    <tr>
                        <td class="id-info escape">NOMBRE</td>
                        <td>nombre-usuario</td>
                    </tr>
                    <tr>
                        <td class="id-info escape">APELLIDO</td>
                        <td>apellido-usuario</td>
                    </tr>
                    <tr>
                        <td class="id-info escape">EMAIL</td>
                        <td>email-usuario</td>
                    </tr>
                </table> 
            </div>
        </div>
        <div class="fav-animes">
            <div class="titulo-animes dirty">ANIMES FAVORITOS</div>
            <div class="animes"></div>
        </div>
        <div class="panel-control">
            <div class="control"></div>
            <div class="control"></div>
            <div class="control"></div>
        </div>

    </div>