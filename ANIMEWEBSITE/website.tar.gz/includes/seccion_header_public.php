<div class="menu-registro">
            <button onclick="location.href='login.php'" class="dirty" >LOGIN / REGISTRO</button>
            <label class="logo-registro"></label>
</div>