<div class="menu-registro">
            <div id="personal"><button onclick="location.href='../Personal.php'">Acceso a usuario</button></div>
            <button id="cerrar-sesion" onclick="location.href='cerrarSesion.php'">CERRAR SESIÓN </button>
            <label class="logo-registro"></label>
</div>