function cargar() {
    console.log("Pagina cargada...");
    
}




window.addEventListener("load", cargar, false);